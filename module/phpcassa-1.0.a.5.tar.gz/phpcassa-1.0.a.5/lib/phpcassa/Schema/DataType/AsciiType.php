<?php
namespace phpcassa\Schema\DataType;

/**
 * Stores data as ASCII strings.
 *
 * @package phpcassa\Schema\DataType
 */
class AsciiType extends CassandraType { }
