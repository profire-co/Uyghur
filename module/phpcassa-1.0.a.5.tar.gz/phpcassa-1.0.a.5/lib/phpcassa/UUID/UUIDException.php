<?php
namespace phpcassa\UUID;

/**
 * @package phpcassa\Util
 */
class UUIDException extends \Exception {
}
